
Proyecto DS6 - Android Studio Parte I

Creado por: Raúl Arcia 2-753-1259, Johny Medina 8-954-566

Descripción del Proyecto
Este proyecto de Android Studio consiste en buscar un correo electrónico utilizando la cédula (ID) de un usuario. Se utiliza una base de datos MySQL alojada en un servidor local con XAMPP para almacenar y consultar los datos.

Requisitos
Android Studio
XAMPP (para el servidor local)
Conexión a internet (para descargar dependencias)
Navegador web (para probar la API PHP)
Configuración del Servidor Local
Instalar XAMPP en tu máquina local.
Iniciar los servicios de Apache y MySQL desde el panel de control de XAMPP.
Colocar la carpeta "android" con los archivos db-android.php y buscarDatos.php en la carpeta htdocs de XAMPP.

Datos de Conexión
usuario = d62024
Contraseña = 123456

Datos Adicionales
Cambiar dirección IP en el URL del "MainActivity.java" (línea 47) en Android Studio y colocar la carpeta "android" con los archivos .php dentro del disco local C: en Xammp/htdocs


