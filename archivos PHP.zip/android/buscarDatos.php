<?php
include 'db-android.php'; // Incluir el archivo de conexión

if (isset($_GET['cedula'])) {
    $cedula = $_GET['cedula'];
    $sql = "SELECT nombre1, nombre2, apellido1, apellido2, direccion, telefono, email FROM personal WHERE cedula='$cedula'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response = array_merge($row, ["message" => "Usuario encontrado."]);
        echo json_encode($response);
    } else {
        echo json_encode(["error" => "Usuario no existente."]);
    }
} else {
    echo json_encode(["error" => "Cédula no proporcionada."]);
}

$conn->close();
?>